/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.asi.restaurantbcd.controller.mtto;

import javax.inject.Named;
import javax.enterprise.context.RequestScoped;

/**
 *
 * @author desaext1
 */
@Named(value = "mttoUsuario")
@RequestScoped
public class MttoUsuarioMB {

    /**
     * Creates a new instance of MttoUsuarioManagedBean
     */
    public MttoUsuarioMB() {
    }
    
}
